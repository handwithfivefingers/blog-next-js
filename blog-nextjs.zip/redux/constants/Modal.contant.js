export const Modal = {
  SHOW_UP: 'SHOW_UP',
  HIDE: 'HIDE'
}