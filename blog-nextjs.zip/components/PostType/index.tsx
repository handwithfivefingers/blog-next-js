import React from 'react';

const PostType = (props) => {
  return <div></div>;
};

export default PostType;
