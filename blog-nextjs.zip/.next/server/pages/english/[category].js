(() => {
var exports = {};
exports.id = 475;
exports.ids = [475];
exports.modules = {

/***/ 4637:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4758);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6742);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_UI_CardPost_CardPostStyle1__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5249);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_html_parser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7795);
/* harmony import */ var react_html_parser__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_html_parser__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1704);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_Content__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8271);
/* harmony import */ var _constant_category__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7515);
/* harmony import */ var _helper_Context__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5216);
/* harmony import */ var react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4885);
/* harmony import */ var react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_UI_CardPost_CardPostStyle2__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7099);
/* harmony import */ var _components_UI_SkeletonLoading__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9938);


















const Categories = ({
  cate
}) => {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
  const {
    0: post,
    1: setPost
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
  const {
    rowLayout
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_helper_Context__WEBPACK_IMPORTED_MODULE_11__/* .default */ .ZP);
  const {
    0: title,
    1: setTitle
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
  const {
    0: pagi,
    1: setPagi
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
    after: false,
    end: ''
  });
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    fetchPost({});
  }, [router.query.category]);

  const fetchPost = async ({
    first = 12,
    after = ''
  }) => {
    const {
      data
    } = await (0,_constant_category__WEBPACK_IMPORTED_MODULE_10__/* .getEnglishCategoriesSlug */ .op)({
      first,
      slug: router.query.category,
      after
    });
    let defaultData = data.allEnglishCategories.edges[0].node.english.nodes;
    let pageInfo = data.allEnglishCategories.edges[0].node.english.pageInfo;
    title == data.allEnglishCategories.edges[0].node.name ? '' : setTitle(data.allEnglishCategories.edges[0].node.name);
    setPagi(prevState => {
      if (prevState.end == pageInfo.endCursor) {
        return prevState;
      } else {
        return {
          end: pageInfo.endCursor,
          after: pageInfo.hasNextPage
        };
      }
    });
    let newData = (post === null || post === void 0 ? void 0 : post.length) > 0 ? post.concat(defaultData) : defaultData || defaultData;
    setPost(() => Array.from(new Set(newData)));
  };

  const renderLoading = () => {
    let xhtml = [];

    if (rowLayout) {
      for (let i = 0; i < 12; i++) {
        xhtml.push( /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "col-lg-3 col-md-4 col-sm-6 col-6 mb-4",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_8___default()), {
            style: {
              paddingBottom: '75%'
            },
            duration: 2
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_8___default()), {
            duration: 2
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_8___default()), {
            count: 4,
            duration: 2
          })]
        }, i));
      }
    } else {
      for (let i = 0; i < 12; i++) {
        xhtml.push( /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
          className: "col-md-12",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "row",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
              className: "col-md-3 col-4",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_8___default()), {
                height: 150,
                duration: 2
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
              className: "col-md-9 col-8",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_8___default()), {
                count: 2,
                duration: 2
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                  display: 'flex',
                  flexDirection: 'row'
                },
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_8___default()), {
                  count: 1,
                  duration: 2
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_8___default()), {
                  count: 1,
                  duration: 2
                })]
              })]
            })]
          })
        }, i));
      }
    }

    return xhtml;
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_6___default()), {
      children: react_html_parser__WEBPACK_IMPORTED_MODULE_7___default()(cate[0].seo.fullHead)
    }), post ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Content__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
      title: title,
      content: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_15___default().wrapper),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_12___default()), {
          className: "row",
          style: {
            overflow: 'unset'
          },
          dataLength: post === null || post === void 0 ? void 0 : post.length,
          next: () => fetchPost({
            after: pagi === null || pagi === void 0 ? void 0 : pagi.end
          }),
          hasMore: pagi.after,
          endMessage: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            children: "Found Nothing ..."
          }),
          loader: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_UI_SkeletonLoading__WEBPACK_IMPORTED_MODULE_14__/* .default */ .Z, {}),
          children: post === null || post === void 0 ? void 0 : post.map(item => {
            var _item$featuredImage, _item$featuredImage2;

            return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
              className: `${rowLayout ? 'col-lg-3 col-md-4 col-sm-6 col-6 mb-4' : 'col-md-12'}`,
              children: rowLayout ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_UI_CardPost_CardPostStyle1__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
                id: item.id,
                link: item.uri,
                title: item.title,
                image: (_item$featuredImage = item.featuredImage) === null || _item$featuredImage === void 0 ? void 0 : _item$featuredImage.node.mediaItemUrl,
                categories: item.englishCategories,
                views: item.views.views
              }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_UI_CardPost_CardPostStyle2__WEBPACK_IMPORTED_MODULE_13__/* .default */ .Z, {
                id: item.id,
                link: `${item.uri}`,
                title: item.title,
                image: (_item$featuredImage2 = item.featuredImage) === null || _item$featuredImage2 === void 0 ? void 0 : _item$featuredImage2.node.mediaItemUrl,
                categories: item.englishCategories,
                views: item.views.views
              })
            }, item.uri);
          })
        })
      })
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Content__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
      title: post === null || post === void 0 ? void 0 : post.categories.edges[0].node.name,
      content: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_15___default().wrapper),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
          className: "row",
          style: {
            margin: 0
          },
          children: renderLoading()
        })
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Categories);
const getStaticProps = async context => {
  const {
    data
  } = await _apollo_client__WEBPACK_IMPORTED_MODULE_2__/* .default.query */ .Z.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_3__.gql`
      query MyQuery($slug: [String] = "") {
        allEnglishCategories(first: 999, where: { slug: $slug }) {
          nodes {
            seo {
              fullHead
            }
          }
        }
      }
    `,
    variables: {
      slug: context.params.category
    }
  });
  return {
    props: {
      cate: data.allEnglishCategories.nodes,
      revalidate: 60 * 60 * 24
    }
  };
};
const getStaticPaths = async () => {
  const {
    data
  } = await _apollo_client__WEBPACK_IMPORTED_MODULE_2__/* .default.query */ .Z.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_3__.gql`
      query MyQuery {
        allEnglishCategories(first: 999) {
          nodes {
            id
            name
            slug
          }
        }
      }
    `
  });
  const paths = data.allEnglishCategories.nodes.map(item => {
    return {
      params: {
        category: item.slug.toString(),
        key: item.id
      }
    };
  });
  return {
    paths,
    fallback: false
  };
};

/***/ }),

/***/ 6742:
/***/ ((module) => {

// Exports
module.exports = {
	"header_content": "style_header_content__2E2BQ",
	"imageFeature": "style_imageFeature__1w2AF",
	"title": "style_title__3xBeE"
};


/***/ }),

/***/ 8074:
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 7795:
/***/ ((module) => {

"use strict";
module.exports = require("react-html-parser");

/***/ }),

/***/ 4885:
/***/ ((module) => {

"use strict";
module.exports = require("react-infinite-scroll-component");

/***/ }),

/***/ 1704:
/***/ ((module) => {

"use strict";
module.exports = require("react-loading-skeleton");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [445,675,444,271,742,938,99,515], () => (__webpack_exec__(4637)));
module.exports = __webpack_exports__;

})();