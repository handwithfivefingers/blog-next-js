"use strict";
(() => {
var exports = {};
exports.id = 773;
exports.ids = [773];
exports.modules = {

/***/ 9411:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Site),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

;// CONCATENATED MODULE: external "next-sitemap"
const external_next_sitemap_namespaceObject = require("next-sitemap");
// EXTERNAL MODULE: ./constant/sitemap.tsx
var sitemap = __webpack_require__(6133);
;// CONCATENATED MODULE: ./pages/server-sitemap.xml/index.tsx


const url = 'https://nextjs.truyenmai.com';
const getServerSideProps = async ctx => {
  // const cateResponse = await cateSitemap;
  const postsResponse = await sitemap/* postSitemap */.G9;
  const englishResponse = await sitemap/* englishSitemap */.Ry;
  const projectResponse = await sitemap/* projectSitemap */.mb; // const categories = cateResponse.data.categories.edges.map((cate) => ({
  //   loc: `${url}${cate.node.uri}`,
  //   lastmod: new Date().toISOString(),
  // }));

  const posts = postsResponse.data.posts.edges.map(post => ({
    loc: `${url}${post.node.uri}`,
    lastmod: new Date().toISOString()
  }));
  const english = englishResponse.data.allEnglish.edges.map(english => ({
    loc: `${url}${english.node.uri}`,
    lastmode: new Date().toISOString()
  }));
  const project = projectResponse.data.allProject.edges.map(project => ({
    loc: `${url}${project.node.uri}`,
    lastmode: new Date().toISOString()
  })); // const fields: ISitemapField[] = posts;

  const fields = posts.concat(english).concat(project);
  return (0,external_next_sitemap_namespaceObject.getServerSideSitemap)(ctx, fields);
};
function Site() {}

/***/ }),

/***/ 8074:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [133], () => (__webpack_exec__(9411)));
module.exports = __webpack_exports__;

})();