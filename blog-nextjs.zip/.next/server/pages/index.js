(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 4928:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./components/UI/CardPost/CardPostStyle1/index.tsx
var CardPostStyle1 = __webpack_require__(5249);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./redux/store/hook.tsx
var hook = __webpack_require__(3629);
// EXTERNAL MODULE: ./redux/actions/index.js + 1 modules
var actions = __webpack_require__(7390);
// EXTERNAL MODULE: ./components/UI/VideoPost/style.module.scss
var style_module = __webpack_require__(7736);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
;// CONCATENATED MODULE: ./components/UI/VideoPost/index.tsx








const VideoPost = ({
  link
}) => {
  const dispatch = (0,hook/* useAppDispatch */.T)();

  const renderModal = link => {
    dispatch((0,actions/* ShowupModal */.m)(link));
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (style_module_default()).video_post,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (style_module_default()).video_post_img,
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: `https://img.youtube.com/vi/${link}/0.jpg`,
        layout: "responsive",
        width: "250",
        height: "200",
        unoptimized: true,
        alt: "...",
        onClick: e => {
          renderModal(link);
        }
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (style_module_default()).video_post_content,
      children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
        className: (style_module_default()).title,
        children: "Title"
      })
    })]
  });
};

/* harmony default export */ const UI_VideoPost = (VideoPost);
// EXTERNAL MODULE: ./components/UI/Carousel/Carousel.module.scss
var Carousel_module = __webpack_require__(9254);
var Carousel_module_default = /*#__PURE__*/__webpack_require__.n(Carousel_module);
;// CONCATENATED MODULE: ./components/UI/Carousel/index.tsx






/**
 * @function renderCarousel
 * @param {  id,title,image,categories,link,views} item
 * @param { number } column
 * @param { null } typpe
 * @returns { Carousel }
 */

const Carousel = ({
  item,
  column,
  type = null
}) => {
  const {
    0: current,
    1: setCurrent
  } = (0,external_react_.useState)(0);
  const {
    0: touchStart,
    1: setTouchStart
  } = (0,external_react_.useState)(0);
  const {
    0: touchEnd,
    1: setTouchEnd
  } = (0,external_react_.useState)(0);
  const {
    0: winWidth,
    1: setWidth
  } = (0,external_react_.useState)(null); // const [winMatches, setWindowMatches] = useState(false);

  (0,external_react_.useEffect)(() => {
    setWidth(window.innerWidth);
  }, [winWidth]); // useEffect(() => {
  //   matchScreenSize();
  // }, []);

  const renderListSlider = () => {
    let xhtml = [];

    if (!type) {
      for (let i = 0; i < item.length; i++) {
        var _item$i$featuredImage;

        let style = {
          '--offset': i - current,
          '--dir': column
        };
        xhtml.push( /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (Carousel_module_default()).slide,
          style: style,
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (Carousel_module_default()).slide_wrapper,
            children: /*#__PURE__*/jsx_runtime_.jsx(CardPostStyle1/* default */.Z, {
              id: item[i].id,
              title: item[i].title,
              image: (_item$i$featuredImage = item[i].featuredImage) === null || _item$i$featuredImage === void 0 ? void 0 : _item$i$featuredImage.node.sourceUrl,
              categories: item[i].categories,
              link: item[i].uri,
              views: item[i].views
            })
          })
        }, i));
      }
    } else if (type === 'link') {
      for (let i = 0; i < item.length; i++) {
        var _item$i;

        let style = {
          '--offset': i - current,
          '--dir': column
        };
        xhtml.push( /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (Carousel_module_default()).slide,
          style: style,
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (Carousel_module_default()).slide_wrapper,
            children: /*#__PURE__*/jsx_runtime_.jsx(UI_VideoPost, {
              link: (_item$i = item[i]) === null || _item$i === void 0 ? void 0 : _item$i.section2LinkItem
            })
          })
        }, i));
      }
    } else if (type === 'banner') {
      for (let i = 0; i < item.length; i++) {
        var _item$i$featuredImage2;

        let style = {
          '--offset': i - current,
          '--dir': column
        };
        xhtml.push( /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (Carousel_module_default()).slide,
          style: style,
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (Carousel_module_default()).slide_wrapper,
            children: /*#__PURE__*/jsx_runtime_.jsx(CardPostStyle1/* default */.Z, {
              id: item[i].id,
              title: item[i].title,
              image: (_item$i$featuredImage2 = item[i].featuredImage) === null || _item$i$featuredImage2 === void 0 ? void 0 : _item$i$featuredImage2.node.sourceUrl,
              categories: item[i].categories,
              link: item[i].uri,
              views: item[i].views
            })
          })
        }, i));
      }
    }

    return xhtml;
  };

  const prevEvent = (width = null) => {
    if (current > 0) {
      if (width && width < -200) {
        let numState = Math.round(width / 200); // làm tròn số slide khi swipe

        setCurrent(prevState => {
          if (prevState + numState > 0) {
            // state mới > 0 trả về state mới
            return prevState + numState;
          } else {
            return prevState - 1;
          }
        });
      } else {
        setCurrent(prevState => prevState - 1);
      }
    } else {
      return;
    }
  };

  const nextEvent = (width = null) => {
    const columnCondition = condition();

    if (current + columnCondition >= item.length + 1) {
      return;
    } else {
      if (width && width >= 200) {
        let numState = Math.round(width / 200); // làm tròn số slide khi swipe

        setCurrent(prevState => {
          if (prevState + numState < item.length - columnCondition) {
            return prevState + numState;
          } else {
            return item.length - columnCondition;
          }
        });
      } else {
        setCurrent(prevState => {
          if (prevState >= item.length - columnCondition) {
            return prevState;
          } else if (prevState + 1 === item.length - columnCondition) {
            return item.length - columnCondition;
          } else {
            return prevState + 1;
          }
        });
      }
    }
  };

  const condition = () => {
    // Desktop low and high resolution
    if (column === 2 && winWidth > 990) {
      return 2;
    } else if (column === 3 && winWidth > 990) {
      return 3;
    } else if (column === 4 && winWidth > 990) {
      return 4;
    } else if (column === 5 && winWidth > 990) {
      return 5;
    } // Tablet high resolution
    else if (column > 2 && winWidth <= 990 && winWidth > 768) {
        return 2;
      } else if (column === 2 && winWidth <= 990 && winWidth > 768) {
        return 2;
      } // Tablet low resolution
      else if (column > 1 && winWidth <= 768 && winWidth > 550) {
          return 2;
        } else if (column === 1 && winWidth <= 768 && winWidth > 550) {
          return 1;
        } // Mobile
        else if (column >= 1 && winWidth <= 550) {
            return 1;
          }
  };

  const handleTouchStart = e => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = e => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    let width = touchStart - touchEnd;

    if (touchStart - touchEnd > 75) {
      // do your stuff here for left swipe
      nextEvent(width);
    }

    if (touchStart - touchEnd < -75) {
      // do your stuff here for right swipe
      prevEvent(width);
    }
  }; // const matchScreenSize = () => {
  //   const handler = (e) => setWindowMatches(e.matches);
  //   window.matchMedia('(max-width: 1300px)').addListener(handler);
  // };


  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (Carousel_module_default()).row,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Carousel_module_default()).carousel,
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Carousel_module_default()).sliders,
        onTouchStart: touchStartEvent => handleTouchStart(touchStartEvent),
        onTouchMove: touchMoveEvent => handleTouchMove(touchMoveEvent),
        onTouchEnd: () => handleTouchEnd(),
        children: renderListSlider()
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (Carousel_module_default()).dot_slider,
      children: [current <= 0 ? '' : /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: `${(Carousel_module_default()).prev_btn}`,
        onClick: prevEvent,
        children: `<`
      }), current >= item.length - condition() ? '' : /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (Carousel_module_default()).next_btn,
        onClick: nextEvent,
        children: `>`
      })]
    })]
  });
};

/* harmony default export */ const UI_Carousel = (Carousel);
// EXTERNAL MODULE: ./constant/page.tsx
var page = __webpack_require__(3061);
// EXTERNAL MODULE: external "react-html-parser"
var external_react_html_parser_ = __webpack_require__(7795);
var external_react_html_parser_default = /*#__PURE__*/__webpack_require__.n(external_react_html_parser_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./assets/css/home.module.scss
var home_module = __webpack_require__(2368);
var home_module_default = /*#__PURE__*/__webpack_require__.n(home_module);
// EXTERNAL MODULE: ./components/UI/CardProject/styles.module.scss
var styles_module = __webpack_require__(9457);
var styles_module_default = /*#__PURE__*/__webpack_require__.n(styles_module);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var index_esm = __webpack_require__(9583);
;// CONCATENATED MODULE: ./components/UI/CardProject/index.tsx






const index = props => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (styles_module_default()).project_wrapper,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (styles_module_default()).project_img,
      style: {
        backgroundImage: `url(${props.img})`
      },
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (styles_module_default()).project_content,
        children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
          children: props.title || 'Title'
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          children: props.author || 'Author'
        })]
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (styles_module_default()).project_footer,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
        children: [props.like || '5', " ", /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaHeart */.$0H, {})]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
        children: [props.views || '15', " ", /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaEye */.dSq, {})]
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaShare */.Lrt, {})
      })]
    })]
  });
};

/* harmony default export */ const CardProject = (index);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "aos"
var external_aos_ = __webpack_require__(8577);
var external_aos_default = /*#__PURE__*/__webpack_require__.n(external_aos_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./pages/index.tsx















function Home({
  page
}) {
  var _page$seo;

  const {
    0: name,
    1: setName
  } = (0,external_react_.useState)('');
  const {
    0: show,
    1: setShow
  } = (0,external_react_.useState)(false); //show input

  const formRef = (0,external_react_.useRef)(null); // const [modal, setModal] = useState('');

  const section = page === null || page === void 0 ? void 0 : page.frontpage;
  const router = (0,router_.useRouter)();

  const submitForm = async e => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('entry.506450849', name);
    const res = fetch('https://docs.google.com/forms/u/0/d/e/1FAIpQLSevkiBjcpkKBwUzWlop904kB8-asiQiHl3eQLlHx90gcCSFOw/formResponse', {
      method: 'POST',
      body: formData
    });
    res.then(res => {}).catch(error => {}).finally(() => {
      setName('');
    });
  };

  (0,external_react_.useEffect)(() => {
    external_aos_default().init({
      duration: 600,
      offset: -100
    });
  }, []);

  const Readmore = ({
    title,
    link
  }) => {
    return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `col-md-12 ${(home_module_default()).head_title}`,
      style: {
        zIndex: 2
      },
      children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
        "data-aos": "fade-zoom-in",
        className: (home_module_default()).title,
        children: title
      }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: link,
        "data-aos": "fade-zoom-in",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
          children: ["Xem t\u1EA5t c\u1EA3", /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaAngleDoubleRight */.hPV, {})]
        })
      })]
    });
  }; // Section 1


  const renderHomeBG = () => {
    let xhtml = null;
    xhtml = /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "p-0",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: `col-md-12 mb-3 ${(home_module_default()).home_bg}`,
        style: {
          maxWidth: '100%',
          backgroundColor: '#f9f9f9',
          backgroundImage: `url(${section.section1.section1Image.sourceUrl})`
        },
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          "data-aos": "fade-up",
          className: (home_module_default()).home_content,
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("h1", {
            style: {
              textAlign: 'center'
            },
            children: ["Welcome to ", /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: "",
              children: "Personal Branding"
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (home_module_default()).btnGroup,
            children: /*#__PURE__*/jsx_runtime_.jsx("button", {
              className: (home_module_default()).btn,
              onClick: () => {
                router.push('/story');
              },
              children: "Discover"
            })
          })]
        })
      })
    });
    return xhtml;
  }; //Section 2


  const renderSection2 = () => {
    let xhtml = null;
    let section2 = section === null || section === void 0 ? void 0 : section.section2;
    let item = section2.section2Carousel === 'By Link' ? section2.section2Linkid : section2.section2Carousel === 'By Post' ? section2.section2.section2Post : null;
    xhtml = /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "row",
      "data-aos": "fade-zoom-in",
      children: [/*#__PURE__*/jsx_runtime_.jsx(Readmore, {
        title: "For Watching",
        link: ""
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        "data-aos": "fade-zoom-in",
        children: /*#__PURE__*/jsx_runtime_.jsx(UI_Carousel, {
          item: item,
          type: "link",
          column: 3
        })
      })]
    });
    return xhtml;
  }; //Section 3


  const renderSection3 = () => {
    // console.log(section?.section3);
    let xhtml = null;
    let section3 = section === null || section === void 0 ? void 0 : section.section3;
    xhtml = /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "row",
      "data-aos": "fade-zoom-in",
      children: [/*#__PURE__*/jsx_runtime_.jsx(Readmore, {
        title: "For Reading",
        link: section3.section3LinkForward ? section3.section3LinkForward : ''
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        "data-aos": "fade-zoom-in",
        children: /*#__PURE__*/jsx_runtime_.jsx(UI_Carousel, {
          item: section3.section3Slider,
          column: 4
        })
      })]
    });
    return xhtml;
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx((head_default()), {
      children: external_react_html_parser_default()(page === null || page === void 0 ? void 0 : (_page$seo = page.seo) === null || _page$seo === void 0 ? void 0 : _page$seo.fullHead)
    }), section.section1 ? renderHomeBG() : '', /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (home_module_default()).wrapper,
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "row",
        "data-aos": "fade-zoom-in",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "col-12",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: (home_module_default()).title,
            style: {
              textAlign: 'center',
              color: 'rgb(0 0 0/75%)',
              fontSize: '22px'
            },
            children: "Tell us your story"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
            onSubmit: submitForm,
            className: (home_module_default()).form,
            children: [/*#__PURE__*/jsx_runtime_.jsx("textarea", {
              value: name,
              onChange: e => setName(e.target.value),
              ref: formRef,
              placeholder: "Describe yourself here..."
            }), /*#__PURE__*/jsx_runtime_.jsx("button", {
              className: "btn",
              type: "submit",
              style: {
                display: 'block',
                margin: '0 auto'
              },
              children: "Submit"
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: `${show ? `${(home_module_default()).form_layer} ${(home_module_default()).active}` : `${(home_module_default()).form_layer} ${(home_module_default()).deactive}`}`
            }), /*#__PURE__*/jsx_runtime_.jsx("button", {
              className: ` ${(home_module_default()).btn}`,
              onClick: () => {
                formRef === null || formRef === void 0 ? void 0 : formRef.current.focus();
                setShow(prevState => !prevState);
              },
              children: show ? 'Close' : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaAngleDoubleDown */.vpT, {})
              })
            })]
          })]
        })
      }), section.section2 ? renderSection2() : '', section.section3 ? renderSection3() : '', /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "row",
        "data-aos": "fade-zoom-in",
        "data-aos-easing": "ease-out-quart",
        children: [/*#__PURE__*/jsx_runtime_.jsx(Readmore, {
          title: "Project/ Programs",
          link: ""
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-xs-12 col-sm-6 col-md-4 col-lg-3 mb-3",
          "data-aos": "zoom-in",
          children: /*#__PURE__*/jsx_runtime_.jsx(CardProject, {
            img: 'https://cdn.dribbble.com/users/746931/screenshots/11132148/media/9777b75b94f416aff7f3f7e299adbb52.png?compress=1&resize=400x300'
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-xs-12 col-sm-6 col-md-4 col-lg-3 mb-3",
          "data-aos": "zoom-in",
          children: /*#__PURE__*/jsx_runtime_.jsx(CardProject, {
            img: 'https://i.pinimg.com/originals/d5/38/92/d53892ca116775c2c3ce77bd4c2d8cc9.jpg'
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-xs-12 col-sm-6 col-md-4 col-lg-3 mb-3",
          "data-aos": "zoom-in",
          children: /*#__PURE__*/jsx_runtime_.jsx(CardProject, {
            img: 'https://cdn.dribbble.com/users/610636/screenshots/11430667/artboard___4_2x_4x.jpg'
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-xs-12 col-sm-6 col-md-4 col-lg-3 mb-3",
          "data-aos": "zoom-in",
          children: /*#__PURE__*/jsx_runtime_.jsx(CardProject, {
            img: 'https://cdn.dribbble.com/users/1820876/screenshots/6201423/preview.jpg'
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-xs-12 col-sm-6 col-md-4 col-lg-3 mb-3",
          "data-aos": "zoom-in",
          children: /*#__PURE__*/jsx_runtime_.jsx(CardProject, {
            img: 'https://i.pinimg.com/originals/81/6f/e2/816fe20323ab2275bd3567cdec8f936f.png'
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-xs-12 col-sm-6 col-md-4 col-lg-3 mb-3",
          "data-aos": "zoom-in",
          children: /*#__PURE__*/jsx_runtime_.jsx(CardProject, {
            img: 'https://cdn.dribbble.com/users/3325754/screenshots/11289182/figo_-_dribble_cover_4x.png'
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-xs-12 col-sm-6 col-md-4 col-lg-3 mb-3",
          "data-aos": "zoom-in",
          children: /*#__PURE__*/jsx_runtime_.jsx(CardProject, {
            img: 'https://assets.materialup.com/uploads/0401769b-2a67-414d-82a4-07477811340b/preview.png'
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-xs-12 col-sm-6 col-md-4 col-lg-3 mb-3",
          "data-aos": "zoom-in",
          children: /*#__PURE__*/jsx_runtime_.jsx(CardProject, {
            img: 'https://cdn.dribbble.com/users/3235024/screenshots/15755387/media/fec1f523f4ac53b8b86cd9e6a21654be.png?compress=1&resize=400x300'
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "row",
        "data-aos": "fade-zoom-in",
        children: [/*#__PURE__*/jsx_runtime_.jsx(Readmore, {
          title: "English Preference",
          link: ""
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-md-4 mb-3",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            style: {
              width: '100%',
              height: 200,
              backgroundColor: '#f9f9f9'
            }
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-md-4 mb-3",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            style: {
              width: '100%',
              height: 200,
              backgroundColor: '#f9f9f9'
            }
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-md-4 mb-3",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            style: {
              width: '100%',
              height: 200,
              backgroundColor: '#f9f9f9'
            }
          })
        })]
      })]
    })]
  });
}
const getStaticProps = async () => {
  const {
    data
  } = await page/* homeQuery */.YG;
  return {
    props: {
      page: data === null || data === void 0 ? void 0 : data.page
    },
    revalidate: 60 * 60
  };
};

/***/ }),

/***/ 2368:
/***/ ((module) => {

// Exports
module.exports = {
	"home_bg": "home_home_bg__2yVXL",
	"home_content": "home_home_content__38iNZ",
	"btnGroup": "home_btnGroup__3A3Yq",
	"btn": "home_btn__ofcsJ",
	"wrapper": "home_wrapper__23CgY",
	"head_title": "home_head_title__1k7Py",
	"title": "home_title__3Yj95",
	"form": "home_form__3f85u",
	"form_layer": "home_form_layer__3poUo",
	"deactive": "home_deactive__L0-qX",
	"iconMoving": "home_iconMoving__3qj19",
	"active": "home_active__1Zia6"
};


/***/ }),

/***/ 9457:
/***/ ((module) => {

// Exports
module.exports = {
	"project_wrapper": "styles_project_wrapper__3-wf9",
	"project_img": "styles_project_img__1Allh",
	"project_content": "styles_project_content__1jDVK",
	"project_footer": "styles_project_footer__3UtsC"
};


/***/ }),

/***/ 9254:
/***/ ((module) => {

// Exports
module.exports = {
	"row": "Carousel_row__3YF7E",
	"dot_slider": "Carousel_dot_slider__nVdY2",
	"prev_btn": "Carousel_prev_btn__32cji",
	"next_btn": "Carousel_next_btn__1y0HM",
	"carousel": "Carousel_carousel__17Wuq",
	"sliders": "Carousel_sliders__39LMe",
	"slide": "Carousel_slide__zVIWX",
	"slide_wrapper": "Carousel_slide_wrapper__5LbJ6"
};


/***/ }),

/***/ 7736:
/***/ ((module) => {

// Exports
module.exports = {
	"default-hover": "style_default-hover__3pOwF",
	"video_post": "style_video_post__3JRMf",
	"video_post_img": "style_video_post_img__Fm5HN",
	"video_post_content": "style_video_post_content__29Ep6",
	"title": "style_title__1bAG9"
};


/***/ }),

/***/ 8074:
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ 8577:
/***/ ((module) => {

"use strict";
module.exports = require("aos");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 7795:
/***/ ((module) => {

"use strict";
module.exports = require("react-html-parser");

/***/ }),

/***/ 79:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [445,675,444,742,61,20], () => (__webpack_exec__(4928)));
module.exports = __webpack_exports__;

})();