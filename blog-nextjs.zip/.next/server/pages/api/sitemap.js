"use strict";
(() => {
var exports = {};
exports.id = 290;
exports.ids = [290];
exports.modules = {

/***/ 8162:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ sitemapFunc)
});

;// CONCATENATED MODULE: external "sitemap"
const external_sitemap_namespaceObject = require("sitemap");
// EXTERNAL MODULE: ./constant/sitemap.tsx
var constant_sitemap = __webpack_require__(6133);
;// CONCATENATED MODULE: ./pages/api/sitemap.tsx


async function sitemapFunc(req, res) {
  res.setHeader('Content-Type', 'text/xml');

  try {
    const postsResponse = await constant_sitemap/* postSitemap */.G9; // call the backend and fetch all stories

    const englishResponse = await constant_sitemap/* englishSitemap */.Ry;
    const projectResponse = await constant_sitemap/* projectSitemap */.mb;
    const smStream = new external_sitemap_namespaceObject.SitemapStream({
      hostname: 'https://' + req.headers.host
    });
    postsResponse.data.posts.edges.map(post => {
      return smStream.write({
        url: post.node.uri,
        lastmod: new Date().toISOString()
      });
    });
    englishResponse.data.allEnglish.edges.map(english => {
      return smStream.write({
        url: english.node.uri,
        lastmod: new Date().toISOString()
      });
    });
    projectResponse.data.allProject.edges.map(project => {
      return smStream.write({
        url: project.node.uri,
        lastmod: new Date().toISOString()
      });
    });
    smStream.end();
    const sitemap = await (0,external_sitemap_namespaceObject.streamToPromise)(smStream).then(sm => sm.toString());
    res.write(sitemap);
    res.end();
  } catch (e) {
    // console.log(e);
    res.statusCode = 500;
    res.end();
  }
}

/***/ }),

/***/ 8074:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [133], () => (__webpack_exec__(8162)));
module.exports = __webpack_exports__;

})();