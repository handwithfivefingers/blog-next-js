(() => {
var exports = {};
exports.id = 275;
exports.ids = [275];
exports.modules = {

/***/ 4709:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _slug_),
  "getStaticPaths": () => (/* binding */ getStaticPaths),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./constant/posts.tsx
var posts = __webpack_require__(3984);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./pages/story/[category]/style.module.scss
var style_module = __webpack_require__(8208);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
// EXTERNAL MODULE: external "react-loading-skeleton"
var external_react_loading_skeleton_ = __webpack_require__(1704);
var external_react_loading_skeleton_default = /*#__PURE__*/__webpack_require__.n(external_react_loading_skeleton_);
;// CONCATENATED MODULE: external "next-seo"
const external_next_seo_namespaceObject = require("next-seo");
// EXTERNAL MODULE: ./components/Content/index.tsx + 3 modules
var Content = __webpack_require__(8271);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./pages/story/[category]/[slug].tsx











const Post = ({
  postBy
}) => {
  var _postBy$featuredImage, _postBy$featuredImage2, _postBy$featuredImage3;

  const router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    // Count views
    if (postBy !== null && postBy !== void 0 && postBy.postId) {
      const res = fetch(`${"https://api.truyenmai.com/wp-json/aalaap/v1/countview"}/${postBy.postId}`, {
        method: 'GET'
      });
      res.then(res => {// console.clear();
      }).catch(error => {
        console.log('error', error);
      });
    } // console.log(postBy);

  }, [postBy]);

  if (router.isFallback) {
    return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "post-content row",
      style: {
        margin: 0
      },
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: `col-12 post-header ${(style_module_default()).header_content}`,
        children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
          className: `title ${(style_module_default()).title}`,
          children: /*#__PURE__*/jsx_runtime_.jsx((external_react_loading_skeleton_default()), {
            width: 200
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (style_module_default()).imageFeature,
          children: /*#__PURE__*/jsx_runtime_.jsx((external_react_loading_skeleton_default()), {
            height: 200
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "col-md-9 col-sm-12 col-xs-12",
        children: /*#__PURE__*/jsx_runtime_.jsx((external_react_loading_skeleton_default()), {
          count: 10,
          delay: 0.5,
          style: {
            margin: '0 auto'
          }
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "col-md-3 col-sm-12 col-xs-12",
        children: /*#__PURE__*/jsx_runtime_.jsx((external_react_loading_skeleton_default()), {
          count: 3
        })
      })]
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/jsx_runtime_.jsx(external_next_seo_namespaceObject.NextSeo, {
      title: postBy === null || postBy === void 0 ? void 0 : postBy.title,
      description: postBy === null || postBy === void 0 ? void 0 : postBy.title,
      canonical: postBy === null || postBy === void 0 ? void 0 : postBy.link,
      openGraph: {
        url: postBy === null || postBy === void 0 ? void 0 : postBy.link,
        title: postBy === null || postBy === void 0 ? void 0 : postBy.title,
        description: postBy === null || postBy === void 0 ? void 0 : postBy.title,
        type: 'article',
        article: {
          publishedTime: '2017-06-21T23:04:13Z',
          modifiedTime: '2018-01-21T18:04:43Z',
          section: 'Section II'
        },
        images: [{
          url: postBy === null || postBy === void 0 ? void 0 : (_postBy$featuredImage = postBy.featuredImage) === null || _postBy$featuredImage === void 0 ? void 0 : (_postBy$featuredImage2 = _postBy$featuredImage.node) === null || _postBy$featuredImage2 === void 0 ? void 0 : _postBy$featuredImage2.mediaItemUrl,
          width: 800,
          height: 600,
          alt: 'Featured Image'
        }]
      }
    }), /*#__PURE__*/jsx_runtime_.jsx(Content/* default */.Z, {
      singlePost: true,
      title: postBy === null || postBy === void 0 ? void 0 : postBy.title,
      img: (postBy === null || postBy === void 0 ? void 0 : (_postBy$featuredImage3 = postBy.featuredImage) === null || _postBy$featuredImage3 === void 0 ? void 0 : _postBy$featuredImage3.node.mediaItemUrl) || 'https://i.ytimg.com/vi/L1tx-wAI6Nw/maxresdefault.jpg',
      content: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "post-content row",
        style: {
          margin: 0
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: `col-12 post-header ${(style_module_default()).header_content}`,
          children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
            className: `title ${(style_module_default()).title}`,
            children: postBy === null || postBy === void 0 ? void 0 : postBy.title
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "row",
          style: {
            padding: 0,
            margin: '0 auto'
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-md-12 col-sm-12 col-xs-12",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "content",
              dangerouslySetInnerHTML: {
                __html: postBy === null || postBy === void 0 ? void 0 : postBy.content
              }
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: `col-md-12 ${(style_module_default()).tag_component}`,
            children: postBy === null || postBy === void 0 ? void 0 : postBy.tags.edges.map(tag => /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: {
                pathname: '/story',
                query: {
                  tag: tag.node.slug
                }
              },
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: (style_module_default()).tag,
                children: tag.node.name
              })
            }, tag.node.slug))
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-md-12 col-sm-12 col-xs-12",
            children: "Related Post"
          })]
        })]
      })
    })]
  });
};

/* harmony default export */ const _slug_ = (Post);
const getStaticProps = async context => {
  let {
    data
  } = await (0,posts/* fetchPostBySlug */.C3)({
    slug: context.params.slug
  }); // console.log(data);

  return {
    props: {
      postBy: data.postBy,
      revalidate: 60 * 60
    }
  };
};
const getStaticPaths = async () => {
  return {
    paths: [],
    fallback: 'blocking' // fallback: true,

  };
};

/***/ }),

/***/ 8208:
/***/ ((module) => {

// Exports
module.exports = {
	"header_content": "style_header_content__2UBGU",
	"imageFeature": "style_imageFeature__1d0ms",
	"title": "style_title__1nHMu",
	"tag_component": "style_tag_component__3F1fc",
	"tag": "style_tag__-15oF"
};


/***/ }),

/***/ 8074:
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 1704:
/***/ ((module) => {

"use strict";
module.exports = require("react-loading-skeleton");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [445,444,271,984], () => (__webpack_exec__(4709)));
module.exports = __webpack_exports__;

})();