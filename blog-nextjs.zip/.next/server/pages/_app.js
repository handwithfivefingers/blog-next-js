(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7108:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "vt": () => (/* binding */ GA_TRACKING_ID),
/* harmony export */   "LV": () => (/* binding */ pageview)
/* harmony export */ });
/* unused harmony export event */
// export const GA_TRACKING_ID = "RP5GM0wMRHOPj6ICk3myPQ";
const GA_TRACKING_ID = 'G-E2045P5WG5'; // https://developers.google.com/analytics/devguides/collection/gtagjs/pages

const pageview = url => {
  window.gtag('config', GA_TRACKING_ID, {
    page_path: url
  });
};
// https://developers.google.com/analytics/devguides/collection/gtagjs/events
const event = ({
  action,
  category,
  label,
  value
}) => {
  window.gtag('event', action, {
    event_category: category,
    event_label: label,
    value
  });
};

/***/ }),

/***/ 2391:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var index_esm = __webpack_require__(9583);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./components/Header/styles.module.scss
var styles_module = __webpack_require__(5840);
var styles_module_default = /*#__PURE__*/__webpack_require__.n(styles_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/Header/index.tsx









const linkList = [{
  path: '/about-us',
  name: 'About Us'
}, {
  path: '/story',
  name: 'Our Story'
}, {
  path: '/english',
  name: 'English'
}, {
  path: '/project-programs',
  name: 'Project/Program'
}, {
  path: '/contact',
  name: 'Contact'
}];

const Header = ({
  loading
}) => {
  const {
    0: show,
    1: setShow
  } = (0,external_react_.useState)(false);
  const {
    0: mMenu,
    1: setMMenu
  } = (0,external_react_.useState)(false);
  const {
    0: search,
    1: setSearch
  } = (0,external_react_.useState)('');
  const {
    0: top,
    1: setTop
  } = (0,external_react_.useState)(0);
  const {
    0: goingUp,
    1: setGoingUp
  } = (0,external_react_.useState)(true);
  const headerRef = (0,external_react_.useRef)();
  const searchRef = (0,external_react_.useRef)();
  const router = (0,router_.useRouter)();

  const searchPush = () => {
    setShow(false);
    router.push({
      pathname: '/search',
      query: {
        search
      }
    });
  };

  let previousTop = 0;
  (0,external_react_.useEffect)(() => {
    setMMenu(false);
  }, [router.route]);
  (0,external_react_.useEffect)(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY; // current
      // headerRef.current = currentScrollY;

      setTop(prevState => {
        previousTop = prevState;

        if (previousTop < currentScrollY && currentScrollY > 65) {
          setGoingUp(false);
        }

        if (previousTop > currentScrollY) {
          setGoingUp(true);
        }

        return currentScrollY;
      });
    }; // if (headerRef.current) {
    //   if (top + 30 < headerRef.current.offsetHeight) {
    //     headerRef.current.setAttribute('style', 'position:relative')
    //   } else {
    //     headerRef.current.setAttribute('style', 'position:fixed')
    //   }
    // }


    window.addEventListener('scroll', handleScroll, {
      passive: true
    });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [top]);
  (0,external_react_.useEffect)(() => {
    if (show && searchRef) {
      // console.log(searchRef);
      searchRef === null || searchRef === void 0 ? void 0 : searchRef.current.focus();
    }
  }, [show, searchRef]);

  const renderSearchBar = () => {
    let xhtml = null;
    xhtml = /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `${(styles_module_default()).SearchModal} ${show ? (styles_module_default()).active : ''}`,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (styles_module_default()).SearchModalBody,
        children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
          placeholder: "Search here...",
          type: "text",
          onChange: e => setSearch(e.target.value),
          ref: searchRef
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          onClick: () => searchPush(),
          children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaSearch */.U41, {})
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (styles_module_default()).GoBack,
        onClick: () => setShow(!show),
        children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaTimes */.aHS, {})
      })]
    });
    return xhtml;
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("header", {
      ref: headerRef,
      className: `${goingUp || loading ? (styles_module_default()).active : (styles_module_default()).deactive} ${(styles_module_default()).headerWrapper}`,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: `${(styles_module_default()).header_destop}`,
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (styles_module_default()).logo,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              style: {
                cursor: 'pointer'
              },
              children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                src: "/image/logo192.png",
                width: "50",
                height: "50",
                layout: "responsive",
                alt: "favicon"
              })
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (styles_module_default()).list_menu,
          children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
            className: (styles_module_default()).menu_item,
            children: linkList.map(item => {
              // console.log(item.path);
              // console.log()
              let routeLength = router.route.split('/');
              let match = routeLength.filter(routeMatch => routeMatch === item.path.split('/')[1]);
              return /*#__PURE__*/jsx_runtime_.jsx("li", {
                className: `${(styles_module_default()).item} ${match.length > 0 ? (styles_module_default()).menu_active : ''}`,
                children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                  href: item.path,
                  children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                    children: item.name
                  })
                })
              }, item.path);
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: (styles_module_default()).searchbar,
          onClick: () => setShow(!show),
          children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaSearch */.U41, {})
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
        className: `${(styles_module_default()).header_mobile}`,
        children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
          className: `${(styles_module_default()).menu_item} ${router.route === '/' ? (styles_module_default()).menu_active : ''} `,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaHome */.xng, {})
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: "Home"
              })]
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: `${(styles_module_default()).menu_item} ${router.route === '/story' ? (styles_module_default()).menu_active : ''} `,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/story",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaHome */.xng, {})
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: "Blog"
              })]
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: `${(styles_module_default()).menu_item}`,
          onClick: () => setShow(!show),
          children: /*#__PURE__*/jsx_runtime_.jsx("span", {
            children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaSearch */.U41, {})
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("li", {
          className: `${(styles_module_default()).menu_item} ${router.route === '/about-us' ? (styles_module_default()).menu_active : ''} `,
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/about-us",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaHome */.xng, {})
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: "About"
              })]
            })
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
          className: (styles_module_default()).menu_item,
          children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
            className: (styles_module_default()).other_item,
            onClick: () => setMMenu(!mMenu),
            children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaEllipsisH */.LCi, {})
          }), mMenu ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            className: (styles_module_default()).menu_dropdown,
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/project-programs",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaHome */.xng, {})
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: "Project"
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/english",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaHome */.xng, {})
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: "English"
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/contact",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaHome */.xng, {})
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: "Contact"
                })]
              })
            })]
          }) : '']
        })]
      })]
    }), renderSearchBar()]
  });
};

/* harmony default export */ const components_Header = (Header); // export const getServerSideProps = async (context) => {
//   const { data } = await menuQuery;
//   return {
//     props: data,
//   };
// };
// EXTERNAL MODULE: ./components/Footer/styles.module.scss
var Footer_styles_module = __webpack_require__(2507);
var Footer_styles_module_default = /*#__PURE__*/__webpack_require__.n(Footer_styles_module);
;// CONCATENATED MODULE: ./components/Footer/index.tsx








const Footer = () => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (Footer_styles_module_default()).scroll_top,
      onClick: () => {
        window.scrollTo({
          top: 0,
          behavior: 'smooth'
        });
      },
      children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaChevronUp */.s$2, {})
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
      style: {
        display: 'flex',
        justifyContent: 'space-around',
        boxShadow: 'var(--main-box-shadow)',
        padding: '50px',
        marginTop: '50px'
      },
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
        style: {
          padding: '0 20px'
        },
        children: ["Powered by", ' ', /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: "/vercel.svg",
            alt: "Vercel Logo",
            width: 72,
            height: 16
          })
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
        style: {
          padding: '0 20px'
        },
        children: ["Copyright ", /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "",
          children: "2019"
        })]
      })]
    })]
  });
};

/* harmony default export */ const components_Footer = (Footer);
// EXTERNAL MODULE: external "@apollo/client"
var client_ = __webpack_require__(8074);
// EXTERNAL MODULE: ./apollo-client.js
var apollo_client = __webpack_require__(4758);
// EXTERNAL MODULE: ./components/Loading/style.module.scss
var style_module = __webpack_require__(8050);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
;// CONCATENATED MODULE: ./components/Loading/index.tsx





const Loading = props => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: `${(style_module_default()).loading} ${props.active ? (style_module_default()).active : ''}`,
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (style_module_default()).pre_loading,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (style_module_default()).lds_ellipsis,
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {}), /*#__PURE__*/jsx_runtime_.jsx("div", {}), /*#__PURE__*/jsx_runtime_.jsx("div", {}), /*#__PURE__*/jsx_runtime_.jsx("div", {})]
      })
    })
  });
};

/* harmony default export */ const components_Loading = (Loading);
;// CONCATENATED MODULE: external "react-modal-video"
const external_react_modal_video_namespaceObject = require("react-modal-video");
var external_react_modal_video_default = /*#__PURE__*/__webpack_require__.n(external_react_modal_video_namespaceObject);
// EXTERNAL MODULE: ./redux/actions/index.js + 1 modules
var actions = __webpack_require__(7390);
// EXTERNAL MODULE: ./redux/store/hook.tsx
var hook = __webpack_require__(3629);
;// CONCATENATED MODULE: ./components/UI/ModalVideo.tsx






const ModalVideos = props => {
  const ModalReducer = (0,hook/* useAppSelector */.C)(state => state.ModalReducer);
  const dispatch = (0,hook/* useAppDispatch */.T)();

  if (ModalReducer.link) {
    return /*#__PURE__*/jsx_runtime_.jsx((external_react_modal_video_default()), {
      channel: "youtube",
      autoplay: true,
      isOpen: ModalReducer ? ModalReducer.show : false,
      videoId: (ModalReducer === null || ModalReducer === void 0 ? void 0 : ModalReducer.link) !== null ? ModalReducer.link : null,
      onClose: () => {
        // console.log('close');
        dispatch((0,actions/* HideModal */.Q)());
      }
    });
  } else {
    return null;
  }
};

/* harmony default export */ const ModalVideo = (ModalVideos);
;// CONCATENATED MODULE: external "@reduxjs/toolkit"
const toolkit_namespaceObject = require("@reduxjs/toolkit");
;// CONCATENATED MODULE: external "redux-thunk"
const external_redux_thunk_namespaceObject = require("redux-thunk");
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_namespaceObject);
// EXTERNAL MODULE: ./redux/constants/Modal.contant.js
var Modal_contant = __webpack_require__(3688);
;// CONCATENATED MODULE: ./redux/reducers/Modal.reducer.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const initialState = {
  show: false,
  link: ''
};
function ModalReducer(state = initialState, action) {
  switch (action.type) {
    case Modal_contant/* Modal.SHOW_UP */.u.SHOW_UP:
      return _objectSpread(_objectSpread({}, state), {}, {
        show: action.payload.show,
        link: action.payload.link
      });

    case Modal_contant/* Modal.HIDE */.u.HIDE:
      return _objectSpread(_objectSpread({}, state), {}, {
        show: action.payload.show,
        link: null
      });

    default:
      return _objectSpread({}, initialState);
  }
}
;// CONCATENATED MODULE: ./redux/reducers/index.ts


const rootReducer = (0,toolkit_namespaceObject.combineReducers)({
  ModalReducer: ModalReducer
});
/* harmony default export */ const reducers = (rootReducer);
;// CONCATENATED MODULE: ./redux/store/index.tsx


 // ...

const store = (0,toolkit_namespaceObject.configureStore)({
  reducer: reducers,
  middleware: getDefaultMiddleware => getDefaultMiddleware().prepend() // prepend and concat calls can be chained
  .concat((external_redux_thunk_default()))
});
/* harmony default export */ const redux_store = (store); // Infer the `RootState` and `AppDispatch` types from the store itself
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(79);
// EXTERNAL MODULE: ./helper/Context.js
var Context = __webpack_require__(5216);
// EXTERNAL MODULE: ./helper/Gtag.tsx
var Gtag = __webpack_require__(7108);
;// CONCATENATED MODULE: ./pages/_app.tsx



function _app_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _app_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { _app_ownKeys(Object(source), true).forEach(function (key) { _app_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { _app_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _app_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
















const isProduction = true;

function MyApp({
  Component,
  pageProps
}) {
  const {
    0: loading,
    1: SetLoading
  } = (0,external_react_.useState)(false);
  const {
    0: rowLayout,
    1: setRowLayout
  } = (0,external_react_.useState)(false);
  const router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    router_default().events.on('routeChangeStart', url => {
      SetLoading(true);
      document.getElementsByTagName('body')[0].classList.add('disabled-scroll');
    });
    router_default().events.on('routeChangeComplete', url => {
      SetLoading(false);
      document.getElementsByTagName('body')[0].classList.remove('disabled-scroll');
    });

    const handleRouteChange = url => {
      /* invoke analytics function only for production */
      if (isProduction) Gtag/* pageview */.LV(url);
    };

    router.events.on('routeChangeComplete', handleRouteChange);
    return () => {
      router.events.off('routeChangeComplete', handleRouteChange);
    };
  }, [router.events]);
  return /*#__PURE__*/jsx_runtime_.jsx(client_.ApolloProvider, {
    client: apollo_client/* default */.Z,
    children: /*#__PURE__*/jsx_runtime_.jsx(external_react_redux_.Provider, {
      store: redux_store,
      children: /*#__PURE__*/jsx_runtime_.jsx(Context/* UserProvider */.dr, {
        value: {
          rowLayout,
          SetRow: () => setRowLayout(!rowLayout)
        },
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "container-fluid",
          style: {
            padding: 0
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(components_Header, {
            loading: loading
          }), loading && /*#__PURE__*/jsx_runtime_.jsx(components_Loading, {
            active: loading
          }) || /*#__PURE__*/jsx_runtime_.jsx(Component, _app_objectSpread({}, pageProps)), /*#__PURE__*/jsx_runtime_.jsx(ModalVideo, {}), /*#__PURE__*/jsx_runtime_.jsx(components_Footer, {})]
        })
      })
    })
  });
}

/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 2507:
/***/ ((module) => {

// Exports
module.exports = {
	"scroll_top": "styles_scroll_top__2ezC9"
};


/***/ }),

/***/ 5840:
/***/ ((module) => {

// Exports
module.exports = {
	"hover": "styles_hover__2DOrr",
	"header_destop": "styles_header_destop__2RBSM",
	"list_menu": "styles_list_menu__1Ms1A",
	"menu_item": "styles_menu_item__2vH8C",
	"item": "styles_item__259Y_",
	"active": "styles_active__-8mDI",
	"deactive": "styles_deactive__2UDsr",
	"headerWrapper": "styles_headerWrapper__3A4T5",
	"logo": "styles_logo__KwRGz",
	"menu_active": "styles_menu_active__2-_LT",
	"searchbar": "styles_searchbar__302Pi",
	"header_mobile": "styles_header_mobile__3Ao8b",
	"menu_dropdown": "styles_menu_dropdown__3HzGk",
	"other_item": "styles_other_item__hGYg2",
	"SearchModal": "styles_SearchModal__I-RfI",
	"SearchModalBody": "styles_SearchModalBody__1Y65P",
	"GoBack": "styles_GoBack__E2zgg"
};


/***/ }),

/***/ 8050:
/***/ ((module) => {

// Exports
module.exports = {
	"loading": "style_loading__2kqqs",
	"pre_loading": "style_pre_loading__23sIV",
	"lds_ellipsis": "style_lds_ellipsis__13MtD",
	"lds-ellipsis1": "style_lds-ellipsis1__3hYG4",
	"lds-ellipsis2": "style_lds-ellipsis2__15P-g",
	"lds-ellipsis3": "style_lds-ellipsis3__3vkmD",
	"active": "style_active__2Fx-r"
};


/***/ }),

/***/ 8074:
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 79:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [445,675,444,20], () => (__webpack_exec__(2391)));
module.exports = __webpack_exports__;

})();