(() => {
var exports = {};
exports.id = 123;
exports.ids = [123];
exports.modules = {

/***/ 4440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constant_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3061);
/* harmony import */ var react_html_parser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7795);
/* harmony import */ var react_html_parser__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_html_parser__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5605);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_UI_CarouselBanner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(359);
/* harmony import */ var _components_Content__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8271);
/* harmony import */ var _constant_posts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3984);
/* harmony import */ var _components_UI_SkeletonLoading__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9938);
/* harmony import */ var react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4885);
/* harmony import */ var react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _helper_Context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5216);
/* harmony import */ var _components_UI_CardPost_CardPostStyle1__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5249);
/* harmony import */ var _components_UI_CardPost_CardPostStyle2__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7099);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1704);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13__);




 // import { contactPage } from '../../constant/page';













const baseURL = '/english';

const ForEnglish = props => {
  const {
    0: post,
    1: setPost
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
  const {
    0: pagi,
    1: setPagi
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
    after: false,
    end: ''
  });
  const {
    rowLayout
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_helper_Context__WEBPACK_IMPORTED_MODULE_10__/* .default */ .ZP);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    fetchEnglishPost({});
  }, []);

  const fetchEnglishPost = async ({
    first = 12,
    after = ''
  }) => {
    const {
      data
    } = await (0,_constant_posts__WEBPACK_IMPORTED_MODULE_7__/* .fetchEnglishQuery */ .os)({
      first,
      after
    }); // console.log(data);

    let defaultData = data.allEnglish.edges;
    let pageInfo = data.allEnglish.pageInfo;
    setPagi(prevState => {
      if (prevState.end == pageInfo.endCursor) {
        return prevState;
      } else {
        return {
          end: pageInfo.endCursor,
          after: pageInfo.hasNextPage
        };
      }
    });
    let newData = (post === null || post === void 0 ? void 0 : post.length) > 0 ? post.concat(defaultData) : defaultData || defaultData;
    setPost(() => Array.from(new Set(newData)));
  };

  const renderSectionTest = () => {
    let xhtml = null;
    let item = [{
      id: 1,
      title: 'Text Banner 1',
      image: 'https://i.ytimg.com/vi/L1tx-wAI6Nw/maxresdefault.jpg',
      categories: '',
      link: '',
      views: 1
    }, {
      id: 2,
      title: 'Text Banner 2',
      image: 'https://i.ytimg.com/vi/L1tx-wAI6Nw/maxresdefault.jpg',
      categories: '',
      link: '',
      views: 2
    }, {
      id: 3,
      title: 'Text Banner 3',
      image: 'https://i.ytimg.com/vi/L1tx-wAI6Nw/maxresdefault.jpg',
      categories: '',
      link: '',
      views: 3
    }, {
      id: 4,
      title: 'Text Banner 4',
      image: 'https://i.ytimg.com/vi/L1tx-wAI6Nw/maxresdefault.jpg',
      categories: '',
      link: '',
      views: 4
    }];
    xhtml = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_UI_CarouselBanner__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
      item: item,
      column: 1
    });
    return xhtml;
  };

  const renderLoading = () => {
    let xhtml = [];

    if (rowLayout) {
      for (let i = 0; i < 12; i++) {
        xhtml.push( /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "col-lg-3 col-md-4 col-sm-6 col-6 mb-4",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13___default()), {
            style: {
              paddingBottom: '75%'
            },
            duration: 2
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13___default()), {
            duration: 2
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13___default()), {
            count: 4,
            duration: 2
          })]
        }, i));
      }
    } else {
      for (let i = 0; i < 12; i++) {
        xhtml.push( /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
          className: "col-md-12",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "row",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
              className: "col-md-3 col-4",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13___default()), {
                height: 150,
                duration: 2
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
              className: "col-md-9 col-8",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13___default()), {
                count: 2,
                duration: 2
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                  display: 'flex',
                  flexDirection: 'row'
                },
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13___default()), {
                  count: 1,
                  duration: 2
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_13___default()), {
                  count: 1,
                  duration: 2
                })]
              })]
            })]
          })
        }, i));
      }
    }

    return xhtml;
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_4___default()), {
      children: react_html_parser__WEBPACK_IMPORTED_MODULE_3___default()(props === null || props === void 0 ? void 0 : props.data.page.seo.fullHead)
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Content__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
      title: "For English",
      carousel: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default().banner_scroll),
        children: [renderSectionTest(), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
          className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default().readMore),
          children: "Xem h\u1EBFt kh\xF3a h\u1ECDc"
        })]
      }),
      content: post ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_9___default()), {
        className: "row",
        style: {
          overflow: 'unset'
        },
        dataLength: post === null || post === void 0 ? void 0 : post.length,
        next: () => fetchEnglishPost({
          after: pagi === null || pagi === void 0 ? void 0 : pagi.end
        }),
        hasMore: pagi.after,
        endMessage: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
          children: "Found Nothing ..."
        }),
        loader: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_UI_SkeletonLoading__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {}),
        children: post === null || post === void 0 ? void 0 : post.map(item => {
          var _item$node$featuredIm, _item$node$featuredIm2;

          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `${rowLayout ? 'col-lg-3 col-md-4 col-sm-6 col-6 mb-4' : 'col-md-12'}`,
            children: rowLayout ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_UI_CardPost_CardPostStyle1__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z, {
              id: item.node.id,
              link: `${item.node.uri}`,
              title: item.node.title,
              image: (_item$node$featuredIm = item.node.featuredImage) === null || _item$node$featuredIm === void 0 ? void 0 : _item$node$featuredIm.node.mediaItemUrl,
              categories: item.node.englishCategories,
              views: item.node.views.views
            }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_UI_CardPost_CardPostStyle2__WEBPACK_IMPORTED_MODULE_12__/* .default */ .Z, {
              id: item.node.id,
              link: `${item.node.uri}`,
              title: item.node.title,
              image: (_item$node$featuredIm2 = item.node.featuredImage) === null || _item$node$featuredIm2 === void 0 ? void 0 : _item$node$featuredIm2.node.mediaItemUrl,
              categories: item.node.englishCategories,
              views: item.node.views.views
            })
          }, item.node.uri);
        })
      }) : renderLoading()
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ForEnglish);
const getServerSideProps = async context => {
  const {
    data
  } = await (0,_constant_page__WEBPACK_IMPORTED_MODULE_2__/* .getSinglePage */ .il)(_constant_page__WEBPACK_IMPORTED_MODULE_2__/* .Pages.ForEnglish */ .iY.ForEnglish);
  return {
    props: {
      data: data // revalidate: 60 * 60,

    }
  };
};

/***/ }),

/***/ 5605:
/***/ ((module) => {

// Exports
module.exports = {
	"banner_scroll": "style_banner_scroll__2FFRR",
	"readMore": "style_readMore__3xcz4"
};


/***/ }),

/***/ 8074:
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 7795:
/***/ ((module) => {

"use strict";
module.exports = require("react-html-parser");

/***/ }),

/***/ 4885:
/***/ ((module) => {

"use strict";
module.exports = require("react-infinite-scroll-component");

/***/ }),

/***/ 1704:
/***/ ((module) => {

"use strict";
module.exports = require("react-loading-skeleton");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [445,675,444,271,742,938,99,61,984,359], () => (__webpack_exec__(4440)));
module.exports = __webpack_exports__;

})();