(() => {
var exports = {};
exports.id = 335;
exports.ids = [335];
exports.modules = {

/***/ 3348:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ contact),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./constant/page.tsx
var page = __webpack_require__(3061);
// EXTERNAL MODULE: external "react-html-parser"
var external_react_html_parser_ = __webpack_require__(7795);
var external_react_html_parser_default = /*#__PURE__*/__webpack_require__.n(external_react_html_parser_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/Content/index.tsx + 3 modules
var Content = __webpack_require__(8271);
// EXTERNAL MODULE: ./pages/contact/style.module.scss
var style_module = __webpack_require__(5441);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
;// CONCATENATED MODULE: external "emailjs-com"
const external_emailjs_com_namespaceObject = require("emailjs-com");
var external_emailjs_com_default = /*#__PURE__*/__webpack_require__.n(external_emailjs_com_namespaceObject);
;// CONCATENATED MODULE: ./pages/contact/index.tsx




 // import { contactPage } from '../../constant/page';







const Contact = props => {
  const {
    0: done,
    1: setDone
  } = (0,external_react_.useState)(false);

  const handleSubmit = e => {
    e.preventDefault();
    external_emailjs_com_default().sendForm('email_truyenmaiblog', 'template_uanusgb', e.target, 'user_KMOFfk2s3H8Q3yRiCYwGH').then(res => setDone(true)).catch(err => console.log(err.repsonse));
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx((head_default()), {
      children: external_react_html_parser_default()(props === null || props === void 0 ? void 0 : props.data.page.seo.fullHead)
    }), /*#__PURE__*/jsx_runtime_.jsx(Content/* default */.Z, {
      singlePost: true,
      title: 'Contact',
      content: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "row",
        style: {
          margin: 0
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
          children: "Contact"
        }), done ? /*#__PURE__*/jsx_runtime_.jsx("h2", {
          children: "C\u1EA3m \u01A1n b\u1EA1n, ch\xFAng t\xF4i s\u1EBD ph\u1EA3n h\u1ED3i l\u1EA1i s\u1EDBm nh\u1EA5t"
        }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
          onSubmit: handleSubmit,
          className: (style_module_default()).form_control,
          children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
            children: "Contact Us "
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).form_item,
            children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
              placeholder: "H\u1ECD v\xE0 T\xEAn:",
              defaultValue: "",
              type: "text",
              name: "name"
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {})]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).form_item,
            children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
              placeholder: "S\u1ED1 \u0110i\u1EC7n Tho\u1EA1i:",
              type: "text",
              name: "phone",
              defaultValue: ""
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {})]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).form_item,
            children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
              placeholder: "Email Li\xEAn L\u1EA1c:",
              type: "email",
              name: "email",
              defaultValue: ""
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {})]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (style_module_default()).form_item,
            children: [/*#__PURE__*/jsx_runtime_.jsx("textarea", {
              placeholder: "L\u1EDDi nh\u1EAFn g\u1EEDi \u0111\u1EBFn:",
              name: "message"
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {})]
          }), /*#__PURE__*/jsx_runtime_.jsx("button", {
            type: "submit",
            className: `${(style_module_default()).btn} btn`,
            children: "G\u1EEDi"
          })]
        })]
      })
    })]
  });
};

/* harmony default export */ const contact = (Contact);
const getStaticProps = async context => {
  const {
    data
  } = await (0,page/* getSinglePage */.il)(page/* Pages.ContactUs */.iY.ContactUs);
  return {
    props: {
      data: data,
      revalidate: 60 * 60
    }
  };
};

/***/ }),

/***/ 5441:
/***/ ((module) => {

// Exports
module.exports = {
	"form_control": "style_form_control__2D5T2",
	"form_item": "style_form_item__2ROUY",
	"btn": "style_btn__1WzLB"
};


/***/ }),

/***/ 8074:
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 7795:
/***/ ((module) => {

"use strict";
module.exports = require("react-html-parser");

/***/ }),

/***/ 1704:
/***/ ((module) => {

"use strict";
module.exports = require("react-loading-skeleton");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [445,444,271,61], () => (__webpack_exec__(3348)));
module.exports = __webpack_exports__;

})();