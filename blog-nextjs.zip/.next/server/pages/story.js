(() => {
var exports = {};
exports.id = 802;
exports.ids = [802];
exports.modules = {

/***/ 5203:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8577);
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(aos__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_html_parser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7795);
/* harmony import */ var react_html_parser__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_html_parser__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4885);
/* harmony import */ var react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1704);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_Content__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8271);
/* harmony import */ var _components_UI_CardPost_CardPostStyle1__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5249);
/* harmony import */ var _components_UI_CardPost_CardPostStyle2__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7099);
/* harmony import */ var _components_UI_SkeletonLoading__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9938);
/* harmony import */ var _constant_page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3061);
/* harmony import */ var _constant_posts__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3984);
/* harmony import */ var _helper_Context__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5216);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1826);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_15__);



















const Blog = props => {
  var _props$page, _props$page$featuredI;

  const {
    0: pagi,
    1: setPagi
  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({
    after: false,
    end: ''
  });
  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
  const {
    0: posts,
    1: setPosts
  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(null);
  const {
    rowLayout
  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_helper_Context__WEBPACK_IMPORTED_MODULE_14__/* .default */ .ZP);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(() => {
    aos__WEBPACK_IMPORTED_MODULE_1___default().init({
      duration: 1200,
      delay: 100
    });
    fetchSinglePost({});
  }, []); // componentDidMount

  const fetchSinglePost = async ({
    first = 12,
    last = null,
    before = '',
    after = '',
    tag = router.query.tag || null
  }) => {
    setLoading(true);
    const {
      data
    } = await (0,_constant_posts__WEBPACK_IMPORTED_MODULE_13__/* .getPostQuery */ ._5)({
      first,
      last,
      before,
      after,
      tag
    });
    let defaultData = data.posts.edges;
    let pageInfo = data.posts.pageInfo;
    setPagi(prevState => {
      if (prevState.end == pageInfo.endCursor) {
        return prevState;
      } else {
        return {
          end: pageInfo.endCursor,
          after: pageInfo.hasNextPage
        };
      }
    });
    let newData = (posts === null || posts === void 0 ? void 0 : posts.length) > 0 ? posts.concat(defaultData) : defaultData || defaultData;
    setPosts(() => Array.from(new Set(newData)));
    setLoading(false);
  };

  const renderLoading = () => {
    let xhtml = [];

    if (rowLayout) {
      for (let i = 0; i < 12; i++) {
        xhtml.push( /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "col-lg-3 col-md-4 col-sm-6 col-6 mb-4",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_7___default()), {
            style: {
              paddingBottom: '75%'
            },
            duration: 2
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_7___default()), {
            duration: 2
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_7___default()), {
            count: 4,
            duration: 2
          })]
        }, i));
      }
    } else {
      for (let i = 0; i < 12; i++) {
        xhtml.push( /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
          className: "col-md-12",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "row",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
              className: "col-md-3 col-4",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_7___default()), {
                height: 150,
                duration: 2
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
              className: "col-md-9 col-8",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_7___default()), {
                count: 2,
                duration: 2
              }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                  display: 'flex',
                  flexDirection: 'row'
                },
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_7___default()), {
                  count: 1,
                  duration: 2
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_loading_skeleton__WEBPACK_IMPORTED_MODULE_7___default()), {
                  count: 1,
                  duration: 2
                })]
              })]
            })]
          })
        }, i));
      }
    }

    return xhtml;
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: react_html_parser__WEBPACK_IMPORTED_MODULE_5___default()(props === null || props === void 0 ? void 0 : props.page.seo.fullHead)
    }), posts ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Content__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
      img: (_props$page = props.page) === null || _props$page === void 0 ? void 0 : (_props$page$featuredI = _props$page.featuredImage) === null || _props$page$featuredI === void 0 ? void 0 : _props$page$featuredI.node.sourceUrl,
      alt: '',
      title: "Our Story",
      content: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_15___default().wrapper),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_6___default()), {
          className: "row",
          style: {
            overflow: 'unset'
          },
          dataLength: posts === null || posts === void 0 ? void 0 : posts.length,
          next: () => {
            var _router$query;

            return fetchSinglePost({
              after: pagi === null || pagi === void 0 ? void 0 : pagi.end,
              tag: (_router$query = router.query) === null || _router$query === void 0 ? void 0 : _router$query.tag
            });
          },
          hasMore: pagi.after,
          endMessage: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            children: "Found Nothing ..."
          }),
          loader: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_UI_SkeletonLoading__WEBPACK_IMPORTED_MODULE_11__/* .default */ .Z, {}),
          children: posts === null || posts === void 0 ? void 0 : posts.map(item => {
            var _item$node$featuredIm, _item$node$featuredIm2;

            return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
              className: `${rowLayout ? 'col-lg-3 col-md-4 col-sm-6 col-6 mb-4' : 'col-md-12'}`,
              children: rowLayout ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_UI_CardPost_CardPostStyle1__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
                id: item.node.id,
                link: `${item.node.uri}`,
                title: item.node.title,
                image: (_item$node$featuredIm = item.node.featuredImage) === null || _item$node$featuredIm === void 0 ? void 0 : _item$node$featuredIm.node.mediaItemUrl,
                categories: item.node.categories,
                views: item.node.views.views
              }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_UI_CardPost_CardPostStyle2__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z, {
                id: item.node.id,
                link: `${item.node.uri}`,
                title: item.node.title,
                image: (_item$node$featuredIm2 = item.node.featuredImage) === null || _item$node$featuredIm2 === void 0 ? void 0 : _item$node$featuredIm2.node.mediaItemUrl,
                categories: item.node.categories,
                views: item.node.views.views
              })
            }, item.node.uri);
          })
        })
      })
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Content__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
      content: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_15___default().wrapper),
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: "row",
          style: {
            margin: 0
          },
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
            style: {
              fontSize: '22px',
              paddingBottom: '50px'
            }
          }), renderLoading()]
        })
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Blog);
const getServerSideProps = async context => {
  const {
    data
  } = await _constant_page__WEBPACK_IMPORTED_MODULE_12__/* .BlogPage */ .vZ;
  return {
    props: data // revalidate: 60 * 60,

  };
};

/***/ }),

/***/ 1826:
/***/ ((module) => {

// Exports
module.exports = {

};


/***/ }),

/***/ 8074:
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ 8577:
/***/ ((module) => {

"use strict";
module.exports = require("aos");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 7795:
/***/ ((module) => {

"use strict";
module.exports = require("react-html-parser");

/***/ }),

/***/ 4885:
/***/ ((module) => {

"use strict";
module.exports = require("react-infinite-scroll-component");

/***/ }),

/***/ 1704:
/***/ ((module) => {

"use strict";
module.exports = require("react-loading-skeleton");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [445,675,444,271,742,938,99,61,984], () => (__webpack_exec__(5203)));
module.exports = __webpack_exports__;

})();