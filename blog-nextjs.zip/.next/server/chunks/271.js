exports.id = 271;
exports.ids = [271];
exports.modules = {

/***/ 8271:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Content)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var index_esm = __webpack_require__(9583);
// EXTERNAL MODULE: ./helper/Context.js
var Context = __webpack_require__(5216);
// EXTERNAL MODULE: ./components/UI/PageHeader/style.module.scss
var style_module = __webpack_require__(9701);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
;// CONCATENATED MODULE: ./components/UI/PageHeader/index.tsx







const PageHeader = props => {
  const {
    rowLayout,
    SetRow
  } = (0,external_react_.useContext)(Context/* default */.ZP);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `row ${(style_module_default()).pageHeader}`,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "col-6",
      children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
        style: {
          fontSize: '22px',
          fontWeight: 400
        },
        children: props.title
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "col-6",
      style: {
        textAlign: 'end'
      },
      children: rowLayout ? /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaTh */.uOL, {
        onClick: () => SetRow(),
        style: {
          cursor: 'pointer'
        }
      }) : /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaThList */.MJA, {
        onClick: () => SetRow(),
        style: {
          cursor: 'pointer'
        }
      })
    })]
  });
};

/* harmony default export */ const UI_PageHeader = (PageHeader);
// EXTERNAL MODULE: external "react-loading-skeleton"
var external_react_loading_skeleton_ = __webpack_require__(1704);
var external_react_loading_skeleton_default = /*#__PURE__*/__webpack_require__.n(external_react_loading_skeleton_);
// EXTERNAL MODULE: ./components/Content/styles.module.scss
var styles_module = __webpack_require__(866);
var styles_module_default = /*#__PURE__*/__webpack_require__.n(styles_module);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ./components/Breadcrumb/style.module.scss
var Breadcrumb_style_module = __webpack_require__(8763);
var Breadcrumb_style_module_default = /*#__PURE__*/__webpack_require__.n(Breadcrumb_style_module);
;// CONCATENATED MODULE: ./constant/router.tsx


const RouterPath = [{
  path: '',
  pathname: '/',
  name: 'Home',
  icon: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaHome */.xng, {})
}, {
  path: 'story',
  pathname: '/story',
  name: 'Our Story',
  icon: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaBook */.Mp$, {})
}, {
  path: 'kinh-nghiem',
  pathname: '/story/kinh-nghiem',
  name: 'Kinh Nghiệm'
}, {
  path: 'chia-se',
  pathname: '/story/chia-se',
  name: 'Chia Sẻ'
}, {
  path: 'english',
  pathname: '/english',
  name: 'For English'
}, {
  path: 'about-us',
  pathname: '/about-us',
  name: 'About Us'
}, {
  path: 'project-programs',
  pathname: '/project-programs',
  name: 'Project/Programs'
}, {
  path: 'contact',
  pathname: '/contact',
  name: 'Contact'
}];
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/Breadcrumb/index.tsx







const Breadcrumb = props => {
  const router = (0,router_.useRouter)(); // console.log(router);

  const SlicePath = () => {
    let xhtml = null;
    let path = router.asPath;
    xhtml = path.split('/').map((item, index) => {
      let pathArr = RouterPath.filter(routerItem => routerItem.path === item);

      if (index === path.split('/').length - 1) {
        return /*#__PURE__*/jsx_runtime_.jsx("li", {
          children: /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: (Breadcrumb_style_module_default()).title,
            children: /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: props.title
            })
          })
        }, index);
      }

      if (index >= 2) {
        return '';
      }

      if (RouterPath.filter(routerItem => routerItem.path === item)) {
        return /*#__PURE__*/jsx_runtime_.jsx("li", {
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: `${pathArr[0].pathname}`,
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              children: pathArr[0].icon ? pathArr[0].icon : pathArr[0].name
            })
          })
        }, item);
      }
    });
    return xhtml;
  };

  return /*#__PURE__*/jsx_runtime_.jsx("ul", {
    className: (Breadcrumb_style_module_default()).breadcrumb,
    children: SlicePath()
  });
};

/* harmony default export */ const components_Breadcrumb = (Breadcrumb);
;// CONCATENATED MODULE: ./components/Content/index.tsx









const Content = props => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [props.carousel ? props.carousel : /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (styles_module_default()).page_image,
      style: {
        backgroundImage: `url(${props.img})`
      },
      children: [props.img ? '' : /*#__PURE__*/jsx_runtime_.jsx((external_react_loading_skeleton_default()), {
        height: 300
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (styles_module_default()).breadcrumb,
        children: /*#__PURE__*/jsx_runtime_.jsx(components_Breadcrumb, {
          title: props.title
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "wrapper",
      children: [props.singlePost ? '' : /*#__PURE__*/jsx_runtime_.jsx(UI_PageHeader, {
        title: props.title
      }), props.content]
    })]
  });
};

/* harmony default export */ const components_Content = (Content);

/***/ }),

/***/ 8763:
/***/ ((module) => {

// Exports
module.exports = {
	"breadcrumb": "style_breadcrumb__3JTWX",
	"icon": "style_icon__12-W4",
	"title": "style_title__2zFcP"
};


/***/ }),

/***/ 866:
/***/ ((module) => {

// Exports
module.exports = {
	"page_image": "styles_page_image__3F_LD",
	"breadcrumb": "styles_breadcrumb__1BIdq"
};


/***/ }),

/***/ 9701:
/***/ ((module) => {

// Exports
module.exports = {
	"pageHeader": "style_pageHeader__3d0A9"
};


/***/ })

};
;