"use strict";
exports.id = 984;
exports.ids = [984];
exports.modules = {

/***/ 3984:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_5": () => (/* binding */ getPostQuery),
/* harmony export */   "os": () => (/* binding */ fetchEnglishQuery),
/* harmony export */   "Fx": () => (/* binding */ fetchProjectQuery),
/* harmony export */   "C3": () => (/* binding */ fetchPostBySlug),
/* harmony export */   "w4": () => (/* binding */ searchQuery)
/* harmony export */ });
/* unused harmony exports FetchSinglePost, SearchPostQuery, FetchAllPost, fetchPostsByTag */
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4758);


const getPostQuery = ({
  after,
  before,
  last,
  first,
  tag
}) => {
  const res = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
      query MyQuery(
        $first: Int = 12
        $last: Int = null
        $before: String = ""
        $after: String = ""
        $tag: [String] = null
      ) {
        posts(
          first: $first
          after: $after
          before: $before
          last: $last
          where: { tagSlugIn: $tag }
        ) {
          pageInfo {
            hasNextPage
            hasPreviousPage
            startCursor
            endCursor
            seo {
              schema {
                raw
              }
            }
          }
          edges {
            node {
              featuredImage {
                node {
                  mediaItemUrl
                }
              }
              id
              link
              title
              uri
              views {
                views
              }
              categories {
                edges {
                  node {
                    name
                    uri
                  }
                }
              }
            }
          }
        }
      }
    `,
    variables: {
      after,
      before,
      first,
      last,
      tag
    },
    notifyOnNetworkStatusChange: true,
    fetchPolicy: 'cache-first'
  });
  return res;
};
const FetchSinglePost = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
  query MyQuery($slug: String = "") {
    postBy(slug: $slug) {
      title
      content
      link
      postId
      featuredImage {
        node {
          mediaItemUrl
        }
      }
      categories {
        edges {
          node {
            name
          }
        }
      }
    }
  }
`;
const SearchPostQuery = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
  query MyQuery($search: String = "") {
    posts(where: { search: $search }) {
      edges {
        node {
          id
          title
          uri
          views {
            views
          }
          categories {
            edges {
              node {
                uri
                name
              }
            }
          }

          featuredImage {
            node {
              mediaItemUrl
            }
          }
        }
      }
    }
  }
`;
const FetchAllPost = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
  query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query MyQuery {
      posts(first: 999) {
        nodes {
          ...PostFragment
          title
          categories {
            ...PostToCategoryConnectionFragment
          }
          uri
        }
      }
    }

    fragment PostFragment on Post {
      id
    }

    fragment CategoryFragment on Category {
      name
      uri
    }

    fragment PostToCategoryConnectionFragment on PostToCategoryConnection {
      nodes {
        ...CategoryFragment
      }
    }
  `
});
const fetchEnglishQuery = ({
  first,
  after
}) => {
  const res = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
      query MyQuery($after: String, $first: Int = 12) {
        allEnglish(first: $first, after: $after) {
          edges {
            node {
              id
              title
              slug
              uri
              views {
                views
              }
              featuredImage {
                node {
                  sourceUrl(size: MEDIUM)
                }
              }
              englishCategories {
                edges {
                  node {
                    name
                    uri
                  }
                }
              }
            }
          }
          pageInfo {
            endCursor
            hasNextPage
            seo {
              schema {
                raw
              }
            }
          }
        }
      }
    `,
    variables: {
      first,
      after
    },
    notifyOnNetworkStatusChange: true,
    fetchPolicy: 'cache-first'
  });
  return res;
};
const fetchProjectQuery = ({
  first,
  after
}) => {
  const res = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
      query MyQuery($after: String, $first: Int = 12) {
        allProject(first: $first, after: $after) {
          edges {
            node {
              id
              title
              slug
              uri
              views {
                views
              }
              featuredImage {
                node {
                  sourceUrl(size: MEDIUM)
                }
              }
              projectCategories {
                edges {
                  node {
                    name
                    uri
                  }
                }
              }
            }
          }
          pageInfo {
            endCursor
            hasNextPage
            seo {
              schema {
                raw
              }
            }
          }
        }
      }
    `,
    variables: {
      first,
      after
    },
    notifyOnNetworkStatusChange: true,
    fetchPolicy: 'cache-first'
  });
  return res;
};
const fetchPostBySlug = ({
  slug
}) => {
  const res = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
      query MyQuery($slug: String = "") {
        postBy(slug: $slug) {
          title
          content
          link
          postId
          featuredImage {
            node {
              mediaItemUrl
            }
          }
          categories {
            edges {
              node {
                name
              }
            }
          }
          tags {
            edges {
              node {
                name
                slug
              }
            }
          }
        }
      }
    `,
    variables: {
      slug
    }
  });
  return res;
};
const fetchPostsByTag = ({
  tag
}) => {
  const res = client.query({
    query: gql`
      query MyQuery($tag: [String] = "") {
        posts(where: { tagSlugIn: $tag }) {
          edges {
            node {
              id
              uri
              title
              featuredImage {
                node {
                  sourceUrl
                }
              }
              views {
                views
              }
            }
          }
          pageInfo {
            endCursor
            hasNextPage
          }
        }
      }
    `,
    variables: {
      tag
    }
  });
  return res;
};
const searchQuery = ({
  search,
  first,
  last,
  before,
  after
}) => {
  const query = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
      query MyQuery(
        $search: String = null
        $after: String
        $before: String
        $first: Int = 12
        $last: Int = null
      ) {
        posts(
          first: $first
          last: $last
          before: $before
          after: $after
          where: { search: $search }
        ) {
          edges {
            node {
              id
              title
              uri
              views {
                views
              }
              categories {
                edges {
                  node {
                    uri
                    name
                  }
                }
              }
              featuredImage {
                node {
                  mediaItemUrl
                }
              }
            }
          }
          pageInfo {
            endCursor
            hasNextPage
            hasPreviousPage
            startCursor
          }
        }
      }
    `,
    variables: {
      search,
      first,
      last,
      before,
      after
    }
  });
  return query;
};

/***/ })

};
;