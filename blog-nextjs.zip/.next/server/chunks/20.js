"use strict";
exports.id = 20;
exports.ids = [20];
exports.modules = {

/***/ 7390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Q": () => (/* reexport */ HideModal),
  "m": () => (/* reexport */ ShowupModal)
});

// EXTERNAL MODULE: ./redux/constants/Modal.contant.js
var Modal_contant = __webpack_require__(3688);
;// CONCATENATED MODULE: ./redux/actions/Modal.action.js

const keys = {
  37: 1,
  38: 1,
  39: 1,
  40: 1
};

function preventDefault(e) {
  e.preventDefault();
}

function preventDefaultForScrollKeys(e) {
  if (keys[e.keyCode]) {
    preventDefault(e);
    return false;
  }
}

const ShowupModal = link => {
  // window.addEventListener('DOMMouseScroll', preventDefault, false); // older FF
  // window.addEventListener('touchmove', preventDefault, false); // mobile
  // window.addEventListener('keydown', preventDefaultForScrollKeys, false);
  return dispatch => {
    dispatch({
      type: Modal_contant/* Modal.SHOW_UP */.u.SHOW_UP,
      payload: {
        show: true,
        link
      }
    });
  };
};
const HideModal = () => {
  // window.removeEventListener('DOMMouseScroll', preventDefault, false);
  // window.removeEventListener('touchmove', preventDefault, false);
  // window.removeEventListener('keydown', preventDefaultForScrollKeys, false);
  return dispatch => {
    dispatch({
      type: Modal_contant/* Modal.HIDE */.u.HIDE,
      payload: {
        show: false,
        link: null
      }
    });
  };
};
;// CONCATENATED MODULE: ./redux/actions/index.js


/***/ }),

/***/ 3688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "u": () => (/* binding */ Modal)
/* harmony export */ });
const Modal = {
  SHOW_UP: 'SHOW_UP',
  HIDE: 'HIDE'
};

/***/ }),

/***/ 3629:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ useAppDispatch),
/* harmony export */   "C": () => (/* binding */ useAppSelector)
/* harmony export */ });
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(79);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);

// Use throughout your app instead of plain `useDispatch` and `useSelector`
const useAppDispatch = () => (0,react_redux__WEBPACK_IMPORTED_MODULE_0__.useDispatch)();
const useAppSelector = react_redux__WEBPACK_IMPORTED_MODULE_0__.useSelector;

/***/ })

};
;