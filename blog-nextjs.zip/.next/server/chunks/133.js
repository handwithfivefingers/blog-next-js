"use strict";
exports.id = 133;
exports.ids = [133];
exports.modules = {

/***/ 4758:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);

const client = new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.ApolloClient({
  uri: `${"https://api.truyenmai.com/graphql"}`,
  cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.InMemoryCache()
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (client);

/***/ }),

/***/ 6133:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G9": () => (/* binding */ postSitemap),
/* harmony export */   "Ry": () => (/* binding */ englishSitemap),
/* harmony export */   "mb": () => (/* binding */ projectSitemap)
/* harmony export */ });
/* unused harmony export cateSitemap */
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4758);


const cateSitemap = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
  query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query MyQuery {
      categories {
        edges {
          node {
            id
            name
            uri
          }
        }
      }
    }
  `
});
const postSitemap = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
  query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query MyQuery {
      posts(first: 9999) {
        edges {
          node {
            uri
          }
        }
      }
    }
  `
});
const englishSitemap = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
  query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query MyQuery {
      allEnglish(first: 9999) {
        edges {
          node {
            uri
          }
        }
      }
    }
  `
});
const projectSitemap = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
  query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query MyQuery {
      allProject(first: 9999) {
        edges {
          node {
            uri
          }
        }
      }
    }
  `
});

/***/ })

};
;