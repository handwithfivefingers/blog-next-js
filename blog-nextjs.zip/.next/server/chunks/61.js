"use strict";
exports.id = 61;
exports.ids = [61];
exports.modules = {

/***/ 3061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "YG": () => (/* binding */ homeQuery),
/* harmony export */   "vZ": () => (/* binding */ BlogPage),
/* harmony export */   "il": () => (/* binding */ getSinglePage),
/* harmony export */   "ed": () => (/* binding */ aboutUsPage),
/* harmony export */   "iY": () => (/* binding */ Pages)
/* harmony export */ });
/* unused harmony exports homeSeoQuery, catePage */
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4758);


const homeSeoQuery = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
  query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query MyQuery {
      page(id: "cG9zdDoy") {
        seo {
          fullHead
        }
      }
    }
  `
});
const homeQuery = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
  query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query MyQuery {
      page(id: "cG9zdDoy") {
        title
        frontpage {
          section1 {
            fieldGroupName
            section1Title
            section1Image {
              sourceUrl
            }
          }
          section2 {
            ...Page_Frontpage_Section2Fragment
          }
          section3 {
            ...Page_Frontpage_Section3Fragment
          }
        }
        seo {
          fullHead
        }
      }
    }

    fragment Page_Frontpage_Section3Fragment on Page_Frontpage_Section3 {
      section3LinkForward
      section3Slider {
        ... on Post {
          id
          title
          uri
          slug
          postId
          featuredImage {
            node {
              sourceUrl
            }
          }
          categories {
            edges {
              node {
                uri
                slug
                name
              }
            }
          }
        }
      }
      section3Title
    }

    fragment Page_Frontpage_Section2Fragment on Page_Frontpage_Section2 {
      section2Carousel
      section2LinkForward
      section2Linkid {
        section2LinkItem
      }
      section2Post {
        ... on Post {
          id
          title
          uri
          slug
          postId
          featuredImage {
            node {
              sourceUrl
            }
          }
          categories {
            edges {
              node {
                uri
                slug
                name
              }
            }
          }
        }
      }
      section2Title
    }
  `
});
const BlogPage = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
  query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query MyQuery {
      page(id: "cG9zdDo3") {
        seo {
          fullHead
        }
        featuredImage {
          node {
            id
            sourceUrl(size: MEDIUM_LARGE)
          }
        }
      }
    }
  `
});
const getSinglePage = id => {
  const res = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
      query MyQuery($id: ID = "") {
        page(id: $id) {
          id
          title
          content(format: RENDERED)
          seo {
            fullHead
          }
        }
      }
    `,
    variables: {
      id
    }
  });
  return res;
};
const aboutUsPage = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
  query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query MyQuery {
      page(id: "cG9zdDoxMjk=") {
        id
        title
        content(format: RENDERED)
        seo {
          fullHead
        }
      }
    }
  `
});
const catePage = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
  query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query MyQuery($slug: [String] = null) {
      categories(where: { slug: $slug }) {
        edges {
          node {
            seo {
              fullHead
            }
          }
        }
      }
    }
  `
});
const Pages = {
  Home: 'cG9zdDoy',
  AboutUs: 'cG9zdDoxMjk=',
  Story: 'cG9zdDo3',
  Search: 'cG9zdDoyNTkz',
  ForEnglish: 'cG9zdDoyNjQz',
  Project: 'cG9zdDo3Mg==',
  ContactUs: 'cG9zdDoyMzA3'
};

/***/ })

};
;