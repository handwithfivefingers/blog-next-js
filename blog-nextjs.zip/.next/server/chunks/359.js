exports.id = 359;
exports.ids = [359];
exports.modules = {

/***/ 359:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5812);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);






/**
 * @function renderCarousel
 * @param {  id,title,image,categories,link,views} item
 * @param { number } column
 * @param { null } typpe
 * @returns { Carousel }
 */

const CarouselBanner = ({
  item,
  column
}) => {
  const {
    0: current,
    1: setCurrent
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
  const {
    0: touchStart,
    1: setTouchStart
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
  const {
    0: touchEnd,
    1: setTouchEnd
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
  const {
    0: winWidth,
    1: setWidth
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null); // const [winMatches, setWindowMatches] = useState(false);

  const {
    0: autoSlide,
    1: setAutoSlide
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    setWidth(window.innerWidth);
    return () => clearInterval(autoSlide);
  }, [winWidth]); // useEffect(() => {
  //   matchScreenSize();
  // }, []);

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    autoRun();
    return () => clearInterval(autoSlide);
  }, []);

  const autoRun = () => {
    const auto = setInterval(() => {
      nextEvent();
    }, 5000);
    setAutoSlide(auto);
  };

  const renderListSlider = () => {
    let xhtml = [];

    for (let i = 0; i < item.length; i++) {
      var _item$i;

      let style = {
        '--offset': i - current,
        '--dir': column
      };
      xhtml.push( /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().slide),
        style: style,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
          className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().slide_wrapper),
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__.default, {
            src: item[i].image,
            width: 1200,
            height: 300,
            layout: "responsive",
            unoptimized: true,
            alt: "..."
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
          className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().content),
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
            children: item[i].title
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            children: item[i].content
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_3__.default, {
            href: (_item$i = item[i]) === null || _item$i === void 0 ? void 0 : _item$i.link,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
              className: "btn",
              children: "Xem Th\xEAm"
            })
          })]
        })]
      }, i));
    }

    return xhtml;
  };

  const prevEvent = (width = null) => {
    if (current > 0) {
      if (width && width < -200) {
        let numState = Math.round(width / 200); // làm tròn số slide khi swipe

        setCurrent(prevState => {
          if (prevState + numState > 0) {
            // state mới > 0 trả về state mới
            return prevState + numState;
          } else {
            return prevState - 1;
          }
        });
      } else {
        setCurrent(prevState => prevState - 1);
      }
    } else {
      return;
    }
  };

  const nextEvent = (width = null) => {
    const columnCondition = condition();

    if (current + columnCondition >= item.length + 1) {
      return;
    } else {
      if (width && width >= 200) {
        let numState = Math.round(width / 200); // làm tròn số slide khi swipe

        setCurrent(prevState => {
          if (prevState + numState < item.length - columnCondition) {
            return prevState + numState;
          } else {
            return item.length - columnCondition;
          }
        });
      } else {
        setCurrent(prevState => {
          if (prevState >= item.length - columnCondition) {
            return 0;
          } else if (prevState + 1 === item.length - columnCondition) {
            return item.length - columnCondition;
          } else {
            return prevState + 1;
          }
        });
      }
    }
  };

  const condition = () => {
    return 1;
  };

  const handleTouchStart = e => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = e => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    let width = touchStart - touchEnd;

    if (touchStart - touchEnd > 75) {
      // do your stuff here for left swipe
      nextEvent(width);
    }

    if (touchStart - touchEnd < -75) {
      // do your stuff here for right swipe
      prevEvent(width);
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().row),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().carousel),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().sliders),
        onTouchStart: touchStartEvent => handleTouchStart(touchStartEvent),
        onTouchMove: touchMoveEvent => handleTouchMove(touchMoveEvent),
        onTouchEnd: () => handleTouchEnd(),
        onMouseEnter: () => clearInterval(autoSlide),
        onMouseLeave: () => autoRun(),
        children: renderListSlider()
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().dot_slider),
      children: [current <= 0 ? '' : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${(_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().prev_btn)}`,
        onClick: prevEvent,
        children: `<`
      }), current >= item.length - condition() ? '' : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().next_btn),
        onClick: nextEvent,
        children: `>`
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CarouselBanner);

/***/ }),

/***/ 5812:
/***/ ((module) => {

// Exports
module.exports = {
	"row": "style_row__3QE3s",
	"dot_slider": "style_dot_slider__2952s",
	"prev_btn": "style_prev_btn__lmXaM",
	"next_btn": "style_next_btn__NHITR",
	"carousel": "style_carousel__12Rsk",
	"sliders": "style_sliders__1Jr3t",
	"slide": "style_slide__46zQ6",
	"slide_wrapper": "style_slide_wrapper__86aVN",
	"content": "style_content__nIFu5",
	"glassTransform": "style_glassTransform__e9Wwr"
};


/***/ })

};
;