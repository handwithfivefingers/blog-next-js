"use strict";
exports.id = 515;
exports.ids = [515];
exports.modules = {

/***/ 7515:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Um": () => (/* binding */ getCategoriesBySlug),
/* harmony export */   "op": () => (/* binding */ getEnglishCategoriesSlug),
/* harmony export */   "xh": () => (/* binding */ getProjectCategoriesSlug)
/* harmony export */ });
/* unused harmony exports AppQuery, CategoriesQuery */
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8074);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4758);


const AppQuery = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
  query MyQuery(
    $after: String
    $before: String
    $first: Int = 12
    $last: Int = null
    $slug: [String] = null
  ) {
    categories(
      first: $first
      after: $after
      before: $before
      last: $last
      where: { slug: $slug }
    ) {
      edges {
        node {
          id
          name
          uri
          posts {
            edges {
              node {
                featuredImage {
                  node {
                    mediaItemUrl
                  }
                }
                id
                link
                title
                uri
                views {
                  views
                }
                categories {
                  edges {
                    node {
                      name
                      uri
                    }
                  }
                }
              }
            }
          }
        }
      }
      pageInfo {
        endCursor
        hasNextPage
        hasPreviousPage
        startCursor
      }
    }
  }
`;
const CategoriesQuery = ({
  after = '',
  before = '',
  first = 12,
  last = null,
  slug = null
}) => {
  const query = client.query({
    query: gql`
      query MyQuery(
        $after: String
        $before: String
        $first: Int = 12
        $last: Int = null
        $slug: [String] = null
      ) {
        categories(
          first: $first
          after: $after
          before: $before
          last: $last
          where: { slug: $slug }
        ) {
          edges {
            node {
              id
              name
              uri
              posts {
                edges {
                  node {
                    featuredImage {
                      node {
                        mediaItemUrl
                      }
                    }
                    id
                    link
                    title
                    uri
                    views {
                      views
                    }
                    categories {
                      edges {
                        node {
                          name
                          uri
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          pageInfo {
            endCursor
            hasNextPage
            hasPreviousPage
            startCursor
          }
        }
      }
    `,
    variables: {
      after,
      before,
      first,
      last,
      slug
    }
  });
  return query;
};
const getCategoriesBySlug = ({
  after = '',
  first = 12,
  slug = null
}) => {
  const query = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
      query MyQuery(
        $after: String
        $before: String
        $first: Int = 12
        $last: Int = null
        $slug: [String] = ""
      ) {
        categories(where: { slug: $slug }) {
          edges {
            node {
              name
              uri
              posts(
                first: $first
                last: $last
                before: $before
                after: $after
              ) {
                ...CategoryToPostConnectionFragment
                pageInfo {
                  startCursor
                  hasPreviousPage
                  hasNextPage
                  endCursor
                }
              }
            }
          }
        }
      }
      fragment NodeWithFeaturedImageToMediaItemConnectionEdgeFragment on NodeWithFeaturedImageToMediaItemConnectionEdge {
        node {
          mediaItemUrl
        }
      }
      fragment CategoryToPostConnectionFragment on CategoryToPostConnection {
        nodes {
          id
          title
          uri
          featuredImage {
            ...NodeWithFeaturedImageToMediaItemConnectionEdgeFragment
          }
          categories {
            edges {
              node {
                name
                uri
              }
            }
          }
          views {
            views
          }
        }
      }
    `,
    variables: {
      after,
      first,
      slug
    }
  });
  return query;
};
const getEnglishCategoriesSlug = ({
  after = '',
  first = 12,
  slug = null
}) => {
  const query = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
      query MyQuery(
        $after: String
        $before: String
        $first: Int = 12
        $last: Int = null
        $slug: [String] = ""
      ) {
        allEnglishCategories(where: { slug: $slug }) {
          edges {
            node {
              name
              uri
              english(
                first: $first
                last: $last
                before: $before
                after: $after
              ) {
                ...EnglishCategoriesToEnglishConnectionFragment
                pageInfo {
                  startCursor
                  hasPreviousPage
                  hasNextPage
                  endCursor
                }
              }
            }
          }
        }
      }
      fragment NodeWithFeaturedImageToMediaItemConnectionEdgeFragment on NodeWithFeaturedImageToMediaItemConnectionEdge {
        node {
          mediaItemUrl
        }
      }
      fragment EnglishCategoriesToEnglishConnectionFragment on EnglishCategoriesToEnglishConnection {
        nodes {
          id
          title
          uri
          featuredImage {
            ...NodeWithFeaturedImageToMediaItemConnectionEdgeFragment
          }
          englishCategories {
            edges {
              node {
                name
                uri
              }
            }
          }
          views {
            views
          }
        }
      }
    `,
    variables: {
      after,
      first,
      slug
    }
  });
  return query;
};
const getProjectCategoriesSlug = ({
  after = '',
  first = 12,
  slug = null
}) => {
  const query = _apollo_client__WEBPACK_IMPORTED_MODULE_1__/* .default.query */ .Z.query({
    query: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
      query MyQuery(
        $after: String
        $before: String
        $first: Int = 12
        $last: Int = null
        $slug: [String] = ""
      ) {
        allProjectCategories(where: { slug: $slug }) {
          edges {
            node {
              name
              uri
              project(
                first: $first
                last: $last
                before: $before
                after: $after
              ) {
                ...ProjectCategoriesToProjectConnectionFragment
                pageInfo {
                  startCursor
                  hasPreviousPage
                  hasNextPage
                  endCursor
                }
              }
            }
          }
        }
      }
      fragment NodeWithFeaturedImageToMediaItemConnectionEdgeFragment on NodeWithFeaturedImageToMediaItemConnectionEdge {
        node {
          mediaItemUrl
        }
      }
      fragment ProjectCategoriesToProjectConnectionFragment on ProjectCategoriesToProjectConnection {
        nodes {
          id
          title
          uri
          featuredImage {
            ...NodeWithFeaturedImageToMediaItemConnectionEdgeFragment
          }
          projectCategories {
            edges {
              node {
                name
                uri
              }
            }
          }
          views {
            views
          }
        }
      }
    `,
    variables: {
      after,
      first,
      slug
    }
  });
  return query;
};

/***/ })

};
;